<?php

    include_once("config.php");
    session_start();
    if(!isset($_SESSION['id'])){
        header("Location:index.php");
    }
    $id=$_SESSION['id'];
    $sql="SELECT * FROM registration WHERE id <> '$id'";
    $query=mysqli_query($conn,$sql);

    // ___________________________________________________________


    $id=$_SESSION['id'];
    $status="pending";
    $sql1="SELECT * FROM friendsrequest WHERE receiverid='$id' AND status='$status'";
    $querypending=mysqli_query($conn,$sql1);


    //--------------------------------------------
    $status1="accept";
    $sql2="SELECT * FROM friendsrequest WHERE receiverid='$id' AND status='$status1'";
    $queryaccept=mysqli_query($conn,$sql2);

?>

<style>
    * {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
    }

    body {
        font-family: Arial, sans-serif;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .header {
        position: fixed;
        display: flex;
        justify-content: space-around;
        align-items: center;
        width: 100%;
        height: 70px;
        background-color: rgb(49, 47, 47);
    }
    .header p{
        color: white;
    }

    .buttons {
        display: flex;
    }
   

    .button1,
    .button2 {
        text-decoration: none;
        font-weight: bold;
        display: inline-block;
        padding: 10px 20px;
        margin-left: 20px;
        color: white;
        outline: none;
        border: none;
    }
    .buttons .button1{
        background-color: green;
        border-radius: 4px;
    }
    .buttons .button2{
        background-color: white;
        border-radius: 4px;
        color: black;
    }
    .button1:hover,.button2:hover{
        text-decoration: underline;
    }
    .main-content {
        display: flex;
        justify-content: space-around;
        align-items: center;
        justify-content: center;
        width: 100%;
        padding-top: 80px;
    }

    /* Responsive adjustments */
    @media only screen and (max-width: 768px) {
        .header {
            flex-direction: column;
            height: auto;
        }

        .buttons {
            margin-top: 10px;
            margin-left: 0;
        }
      

        .button1,
        .button2 {
            margin-left: 0;
            margin-top: 10px;
        }

        .main-content {
            flex-direction: column;
            align-items: center;
        }
    }
    .main-content {
        margin-top: 30px;
        display: flex;
        gap: 500px;
    }

</style>
</head>
<body>
<div class="header">
    <p><?php echo"$_SESSION[username]";?></p>

    <div class="buttons">
        <a href="friends.php" class="button1">Friends</a>   
        <a class="button2" href="logout.php" name="logout">Logout</a>        
    </div>
</div>
    
<div class="main-content">
<table class="f-request">
    <tr>
        <th>Friends Request</th>
    </tr>
    <tr>
    <?php
        while($row=mysqli_fetch_assoc($querypending)){
            echo"<tr><td>{$row['sendername']}</td><td><a href='request_execution.php?btn=accept&senderid=$row[senderid]&receiverid=$id'>Accept</a></td>
            <td><a href='request_execution.php?btn=reject&senderid=$row[senderid]&receiverid=$id'>Reject</a></td><tr>";
        }
    ?>  
    </tr>
</table>
<table class="Friends">
    <tr><th>Friends</th></tr>
    <?php
        while($row=mysqli_fetch_assoc($queryaccept)){
            echo"<tr><td><a href='user_profile.php?msgreceiverid={$row["senderid"]}'>{$row['sendername']}</a></td><tr>";
        }
    ?>    

</table>
<table class="allusers">
    <tr><th>All Users</th></tr>
    <?php
    while( $row=mysqli_fetch_assoc($query)){
    echo"<tr><td>{$row['username']}</td><td><a href='friends_request.php?username={$_SESSION['username']}&senderid=$id&receiverid=$row[id]'>+</a></td>
    <tr>";
}
?>

</table>

</body>
</html>