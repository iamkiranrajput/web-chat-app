<?php
$host="sql301.infinityfree.com";
$db_name="if0_35518174_chatbook";
$user="if0_35518174";
$pass="sRAXnt6Gawai";

$conn= mysqli_connect($host,$user,$pass,$db_name)or die("error");
?>