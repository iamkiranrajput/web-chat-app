<?php

include_once("config.php");
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        *{
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }
        body{
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: rgb(159, 225, 159);

        }
        .container{
            height: 50%;
            width: 50%;
            display: flex;
           align-items: center;
           justify-content: center;
            flex-direction: column;
            gap:10px;
           
        }
        .container .form {
            outline: none;
            border: none;
            padding: 10px 30px;
            text-align: center;
            

        }

        .container div input{
            padding: 10px 30px;
            border-radius: 2px;
            outline: none;
            border: none;
        }
        .input{
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        input:focus, input:hover{
            outline: none;
            border: none;
        }
      
        .buttons #ragister{
            background-color: rgb(55, 155, 55);

        }
        .buttons #sign-up{
            background-color: rgb(41, 41, 179);

        }
        .buttons{

            margin-top: 20px;
            display: flex;
            gap: 20px;
        }
        .buttons input{
            color: white;

        }
       

    </style>
</head>
<body>  
        <div class="container">
            <form action="" method="post">
                <div class="input">
                <input type="text" name="username" placeholder="Username" class="form">
                <input type="password" name="password" placeholder="Password" class="form" > 
                </div>
                <div class="buttons">
                    <input type="submit" name="ragister" value="Register" id="ragister">
                <input type="submit" name="sign-up" value="Sign up" id="sign-up">
            </div>
                
            </form>    
        </div>

</body>
</html>
<?php
if($_SERVER['REQUEST_METHOD']=='POST'){
    $username=filter_input(INPUT_POST, 'username', FILTER_SANITIZE_SPECIAL_CHARS);
    $password=filter_input(INPUT_POST, 'password', FILTER_SANITIZE_SPECIAL_CHARS);

if(isset($_POST['ragister'])){
    $sql= "INSERT INTO registration (username, password)VALUES('$username','$password')";
    $query=mysqli_query($conn, $sql);
    echo"ragistration done";
}
if(isset($_POST['sign-up'])){
    $sql="SELECT * FROM registration WHERE username='$username' AND password='$password'";
    $query=mysqli_query($conn, $sql);

    if(mysqli_num_rows($query)>0){
        $row=mysqli_fetch_assoc($query);
            $_SESSION['id']=$row['id'];
            $_SESSION['username']=$row['username'];
        header("Location:friends.php");
    }
    else{
        echo"user not found";
    }



}

}
?>