<?php
include_once("config.php");

$senderid=$_GET['senderid'];
$receiverid=$_GET['receiverid'];

if($_GET['btn']="accept"){
    $sql="UPDATE friendsrequest SET status='accept' WHERE senderid=$senderid AND receiverid=$receiverid";
    $query=mysqli_query($conn,$sql);
    header('Location:friends.php');
}
else{
    $sql="DELETE friendsrequest WHERE senderid=$senderid AND receiverid=$receiverid";
    $query=mysqli_query($conn,$sql);
    header('Location:friends.php');

}



?>