<?php
include_once("config.php");
$senderid=$_GET['senderid'];
$receiverid=$_GET['receiverid'];
$username=$_GET['username'];
$status='pending';

$checkQuery="SELECT * FROM friendsrequest WHERE senderid='$senderid' AND receiverid='$receiverid'";
$checkQuery=mysqli_query($conn,$checkQuery);

if(mysqli_num_rows($checkQuery)>0){
    header("Location:friends.php");
}else{
$sql="INSERT INTO friendsrequest values('$senderid','$username','$receiverid','$status')";
$query=mysqli_query($conn, $sql);

if($query){
header("Location:friends.php");
}
}
?>