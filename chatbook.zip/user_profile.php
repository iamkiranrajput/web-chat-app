<?php
include_once("config.php");
session_start();
if(!isset($_SESSION['id'])){
    header("Location:index.php");
}
$id=$_SESSION['id'];
$msgreceiverid=$_GET['msgreceiverid'];


$sql="SELECT * FROM msgtable WHERE rec_id=$id";
$query=mysqli_query($conn,$sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .header {
            position: fixed;
            display: flex;
            justify-content: space-around;
            align-items: center;
            width: 100%;
            height: 70px;
            background-color: rgb(49, 47, 47);
        }
        .header p{
            color: white;
        }

        .buttons {
            display: flex;
        }

        .button1,
        .button2 {
            font-weight: bold;
            display: inline-block;
            padding: 10px 20px;
            margin-left: 20px;
            color: white;
            outline: none;
            border: none;
            text-decoration: none;
        }
        .buttons .button1{
        background-color: green;
        border-radius: 4px;
    }
    .buttons .button2{
        background-color: white;
        border-radius: 4px;
        color: black;
    }
    .button1:hover,.button2:hover{
        text-decoration: underline;
    }

        .main-content {
            display: flex;
            justify-content: space-around;
            align-items: center;
            justify-content: center;
            width: 100%;
            padding-top: 80px;
        }

        .updates {
            flex: 1;
            max-width: 400px;
            padding: 20px;
            border-radius: 20px 30px 1px 20px;
            margin-right: 20px;
            background-color: rgb(40, 162, 121);
            width:50px;
            text-align: justify;
        }

        .message {
            flex: 1;
            max-width: 600px;
        }

        textarea {
            width: 100%;
            box-sizing: border-box;
            padding: 10px;
            margin-top: 10px;
        }
        .msg-submit{
            background-color: rgb(32, 54, 163);
            font-weight: bold;
            padding: 10px 20px;
            color: white;
            outline: none;
            border: none;
            text-decoration: none;
            cursor: pointer;
        }
        .updates h4{
            color: rgb(218, 207, 193);
        }
        .updates p{
            font-weight: 600;
            color: rgb(29, 28, 28);
            margin-top: 2px;
        }

        /* Responsive adjustments */
        @media only screen and (max-width: 768px) {
            .header {
                flex-direction: column;
                height: auto;
            }

            .buttons {
                margin-top: 10px;
                margin-left: 0;
            }

            .button1,
            .button2 {
                margin-left: 0;
                margin-top: 10px;
            }

            .main-content {
                flex-direction: column;
                align-items: center;
            }

            .updates,
            .message {
                max-width: 100%;
                margin-right: 0;
            }
        }


    </style>
</head>
<body>
    <div class="header">
    <p><?php echo"$_SESSION[username]";?></p>
        <div class="buttons">
            <a href="friends.php" class="button1">Friends</a>   
            <a class="button2" href="logout.php" name="logout">Logout</a>

        </div>
    </div>
    <div class="main-content">
        <div class="updates">
            <?php

            while($row=mysqli_fetch_assoc($query)){
                echo"<h4>Updates from {$row['send_name']}</h4>";
                echo"<p>{$row['message']}</p>";
            }
            ?>

        </div>

    <form action="" method="post">
        <div class="message">
            <textarea name="msg" id="msg" cols="30" rows="30"></textarea>
            <input type="submit" name="msg-send" value="Send Message" class="msg-submit">
        </div>
    </div>
    </form>
</body>
</html>

<?php
    $send_name=$_SESSION['username'];
    if(isset($_POST['msg-send'])){
        $msg=filter_input(INPUT_POST, 'msg', FILTER_SANITIZE_SPECIAL_CHARS);
        $query="INSERT INTO msgtable(send_id,send_name,rec_id,message)VALUE('$id','$send_name','$msgreceiverid','$msg')";
        mysqli_query($conn,$query);
    }
?>
